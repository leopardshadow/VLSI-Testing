gtime -f "Average memory usage: %K \nMaximum memory usage: %M\n" ./atpg -mod_logicsim -input c17_2.input c17.bench
gtime -f "Average memory usage: %K \nMaximum memory usage: %M\n" ./atpg -mod_logicsim -input c17_3.input c17.bench
gtime -f "Average memory usage: %K \nMaximum memory usage: %M\n" ./atpg -mod_logicsim -input c17_4.input c17.bench
gtime -f "Average memory usage: %K \nMaximum memory usage: %M\n" ./atpg -mod_logicsim -input c17_5.input c17.bench

