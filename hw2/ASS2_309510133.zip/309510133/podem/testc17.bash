./atpg -mod_logicsim -input c17o.input c17.bench
./atpg -logicsim -input c17o.input c17.bench

