./atpg -pattern -num 100 -output c17_2.input c17.bench
./atpg -pattern -num 1000 -output c17_3.input c17.bench
./atpg -pattern -num 10000 -output c17_4.input c17.bench
./atpg -pattern -num 100000 -output c17_5.input c17.bench

